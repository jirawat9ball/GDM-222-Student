using UnityEngine;

namespace Assignment02.StudentSolution
{
    public class Troll
    {

    }
}
