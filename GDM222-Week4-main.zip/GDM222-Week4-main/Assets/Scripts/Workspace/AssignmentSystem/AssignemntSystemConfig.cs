public class AssignmentSystemConfig
{
    public const bool VERBOSE = false;
}