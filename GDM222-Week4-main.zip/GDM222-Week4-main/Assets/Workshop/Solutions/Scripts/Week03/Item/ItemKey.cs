using UnityEngine;

namespace Solution
{
    public class ItemKey : ItemData
    {
        

    }
}
