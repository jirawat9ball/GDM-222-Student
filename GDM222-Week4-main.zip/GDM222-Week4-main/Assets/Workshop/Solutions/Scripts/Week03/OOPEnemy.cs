using UnityEngine;

namespace Solution
{

    public class OOPEnemy : Character
    {
       

       
    }
}